<script>
    var base_url = '<?php echo base_url() ?>';

    $(document).ready(function() {
        window.setInterval(function() {
            cek_pesan_masuk();
        }, 5000);
    });

    function cek_pesan_masuk() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/cek_pesan_masuk",
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                var akun = '';

                if (response.hitung > 0) {
                    response.all_pesan.forEach(ap => {
                        if (response.hitung_terkirim[ap['id']] > 0) {
                            // if (response.status_selisih[ap['id']] == 'ya') {}
                            akun += response.all_akun[ap['id']]['user'] + ', ';
                        }
                    });
                }

                if (response.status_selisih == 'ya') {
                    show_toastr("success", "Success", "Pesan baru dari : " + akun, "center");
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>