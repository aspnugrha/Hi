<script>
    var base_url = '<?php echo base_url() ?>';
    var id_akun = $('#id_akun').val();

    $(document).ready(function() {
        load_profile();
    });

    function load_profile() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Profile/load_profile",
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                $('#foto-profile').removeAttr('src');

                if (response.akun['foto'] != null) {
                    $('#foto-profile').attr('src', base_url + '/' + response.akun['foto']);
                } else {
                    $('#foto-profile').attr('src', '/assets/images/avatar-flat/user1.jpg');
                }

                $('#text-user').text(response.akun['user']);

                if (response.akun['hp'] != null) {
                    var kontak = response.akun['email'] + ' <br> ' + response.akun['hp'];
                } else {
                    var kontak = response.akun['email'];
                }

                $('#text-kontak').html(kontak);
                if (response.akun['bio'] != null) {
                    var bio = response.akun['bio'];
                } else {
                    var bio = '';
                }
                $('#text-bio').html('BIO <br> ' + bio);
                $('#text-total-teman').text(response.jumlah_teman);
                $('#text-total-pesan').text(response.jumlah_pesan);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>