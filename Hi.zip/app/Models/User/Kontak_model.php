<?php

namespace App\Models\User;

use CodeIgniter\Model;

class Kontak_model extends Model
{
    protected $table = 'kontak';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_akun', 'id_akun2', 'tgl	', 'created_at', 'updated_at'];
}
