<script>
    var base_url = '<?php echo base_url() ?>';
    var id_saya = '<?= session()->get('id') ?>'
    var user = '<?= session()->get('user') ?>'

    $(document).ready(function() {
        cek_all_pesan();

        window.setInterval(function() {
            cek_all_pesan();
        }, 5000);
    });

    function cek_all_pesan() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/cek_all_pesan",
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                if (response.hitung > 0) {
                    var html2 = '';
                    response.all_pesan.forEach(ap => {
                        if (response.belum_dibaca[ap['id']] > 0) {
                            var belum_dibaca = '<span class="badge bg-danger rounded-pill float-end">' + response.belum_dibaca[ap['id']] + '</span>';
                        } else {
                            var belum_dibaca = '';
                        }

                        if (response.pesan_terakhir[ap['id']] != null) {
                            var pesan_terakhir = response.pesan_terakhir[ap['id']]['pesan'];
                        } else {
                            var pesan_terakhir = '';
                        }

                        if (response.akun_aktif[ap['id']]['status'] == 'aktif') {
                            var logo_online = '<span class="position-absolute translate-middle p-2 bg-success border border-light rounded-circle"></span>';
                        } else {
                            var logo_online = '';
                        }

                        html2 += '<li class="p-2 border-bottom">' +
                            '<a href="' + base_url + '/pesan/' + response.akun[ap['id']]['user'] + '" class="d-flex justify-content-between a-link-pointer">' +
                            '<div class="d-flex flex-row">' +
                            '<div>' +
                            '<img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp" alt="avatar" class="d-flex align-self-center me-3" width="60">' +
                            logo_online +
                            '</div>' +
                            '<div class="pt-1 text-start">' +
                            '<p class="fw-bold mb-0">' + response.akun[ap['id']]['user'] + '</p>' +
                            '<p class="small text-muted">' + pesan_terakhir + '</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="pt-1">' +
                            '<p class="small text-muted mb-1">' + response.status_aktif[ap['id']] + '</p>' +
                            belum_dibaca +
                            '</div>' +
                            '</a>' +
                            '</li>';
                    });

                    var html = '<div data-mdb-perfect-scrollbar="true" style="position: relative; height: auto;min-height: 300px;">' +
                        '<ul class="list-unstyled mb-0">' +
                        html2 +
                        '</ul>' +
                        '</div>';
                } else {
                    var html = '<center>' +
                        '<br><br>' +
                        '<img class="mb-4" width="100%" src="<?php echo base_url() ?>/assets/images/imgs/no-message.jpg" alt="Logo">' +
                        // '<br><br>' +
                        // '<h1 class="py-4">Selamat Datang, ' + user + '!</h1>' +
                        '<p class="w-50">Mulailah mengirim pesan ke banyak temanmu. Atau anda dapat mencari teman baru dengan mengklik <a class="a-link-pointer" href="' + base_url + '/pesan/baru"><i class="text-danger">Cari Teman</i></a></p>' +
                        '<br><br><br><br>' +
                        '</center>';
                }
                $('#div-all-pesan').html(html);
                console.log(response);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>