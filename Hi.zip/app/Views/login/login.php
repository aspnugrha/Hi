<!DOCTYPE html>
<html class="h-100" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Hi, Login terlebih dahulu!</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>/assets/images/logo/logo.png">
    <!-- <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous"> -->

    <link href="<?php echo base_url() ?>/assets/plugins/toastr/css/toastr.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>/assets/css/style.css" rel="stylesheet">

    <style>
        .a-link-pointer:hover {
            cursor: pointer;
        }
    </style>

</head>

<body class="h-100">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->





    <div class="login-form-bg h-100" style="margin-top: 5%;">
        <div class="container h-100">

            <div class="div-login">
                <div class="row justify-content-center h-100">
                    <div class="col-xl-6">
                        <div class="form-input-content">
                            <div class="card login-form mb-0">
                                <div class="card-body pt-5">
                                    <a href="<?php echo base_url() ?>">
                                        <center>
                                            <img class="mb-4" width="80px" src="<?php echo base_url() ?>/assets/images/logo/logo.png" alt="Logo">
                                        </center>
                                    </a>
                                    <h4 class="text-center">Login</h4>

                                    <form class="mt-5 mb-5 login-input">
                                        <div class="form-group">
                                            <input type="email" id="email" class="form-control" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" id="pass" class="form-control" placeholder="Password">
                                        </div>
                                        <a class="btn login-form__btn submit w-100 text-white" id="btn-login" onclick="cek_login()">Login</a>
                                    </form>
                                    <p class="mt-5 login-form__footer">Belum punya akun? <a class="a-link-pointer text-primary" onclick="div_view('register')">Register</a> sekarang!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="div-register">
                <div class="row justify-content-center h-100">
                    <div class="col-xl-6">
                        <div class="form-input-content">
                            <div class="card login-form mb-0">
                                <div class="card-body pt-5">
                                    <a href="<?php echo base_url() ?>">
                                        <center>
                                            <img class="mb-4" width="80px" src="<?php echo base_url() ?>/assets/images/logo/logo.png" alt="Logo">
                                        </center>
                                    </a>
                                    <h4 class="text-center">Register</h4>

                                    <form class="mt-5 mb-5 login-input" id="form-register">
                                        <?= csrf_field() ?>
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="user-register" id="user-register" placeholder="Username">
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email-register" id="email-register" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" name="pass-register" id="pass-register" placeholder="Password">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" name="confirm_pass" id="confirm_pass" placeholder="Confirm Password">
                                        </div>
                                        <a class="btn login-form__btn submit w-100 text-white" id="btn-register" onclick="cek_register()">Register</a>
                                    </form>
                                    <p class="mt-5 login-form__footer">Sudah punya akun? <a class="a-link-pointer text-primary" onclick="div_view('login')">Login</a> sekarang!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>



    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo base_url() ?>/assets/plugins/common/common.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/custom.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/settings.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/gleek.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/styleSwitcher.js"></script>

    <!-- Toastr -->
    <script src="<?php echo base_url() ?>/assets/plugins/toastr/js/toastr.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/plugins/toastr/js/toastr.init.js"></script>

    <?php
    if ($content_foot != null) {
        foreach ($content_foot as $cf) {
            echo view($cf);
        }
    }
    ?>
</body>

</html>