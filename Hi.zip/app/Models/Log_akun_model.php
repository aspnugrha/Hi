<?php

namespace App\Models;

use CodeIgniter\Model;

class Log_akun_model extends Model
{
    protected $table = 'log_akun';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_akun', 'log', 'created_at', 'updated_at'];
}
