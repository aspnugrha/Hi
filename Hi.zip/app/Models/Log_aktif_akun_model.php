<?php

namespace App\Models;

use CodeIgniter\Model;

class Log_aktif_akun_model extends Model
{
    protected $table = 'log_aktif_akun';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_akun', 'status', 'ip', 'browser', 'lokasi	', 'created_at', 'updated_at'];
}
