<section class="py-2 text-center container">
    <div class="row">
        <div class="col-lg-8 col-md-8 mx-auto" style="background-color: white;height: auto;">

            <?php echo view($content) ?>

        </div>
    </div>
</section>