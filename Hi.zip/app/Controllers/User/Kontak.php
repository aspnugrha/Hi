<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

use App\Models\Akun_model;
use App\Models\Log_akun_model;
use App\Models\Log_aktif_akun_model;
use App\Models\User\Kontak_model;

class Kontak extends BaseController
{
    public function __construct()
    {
        $this->akunModel            = new Akun_model();
        $this->logAkunModel         = new Log_akun_model();
        $this->logAktifAkunModel    = new Log_aktif_akun_model();
        $this->kontakModel          = new Kontak_model();
    }

    public function load_kontak()
    {
        $filter = [
            'id_akun'   => session()->get('id'),
        ];
        $kontak = $this->kontakModel->orderBy('created_at', 'ASC')->where($filter)->findAll();
        $hitung = count($kontak);

        if ($hitung > 0) {
            $kontak2 = [];

            foreach ($kontak as $k) {
                $akun = $this->akunModel->where('id', $k['id_akun2'])->first();

                $kontak2[] = $akun;
            }

            $response = [
                'status' => 'ada',
                'hitung' => $hitung,
                'kontak' => $kontak2,
            ];
        } else {
            $response = ['status' => null];
        }
        echo json_encode($response);
    }

    public function cari_akun()
    {
        $search = $this->request->getVar('search');

        $cari = $this->akunModel->orderBy('created_at', 'ASC')
            ->where('role', 'user')
            ->where("user LIKE '%" . $search . "%' OR email LIKE '%" . $search . "%' OR hp LIKE '%" . $search . "%'")
            ->findAll();

        $jumlah = count($cari);
        if ($jumlah > 0) {

            $kontak     = [];
            $lainnya    = [];

            $jumlah_kontak  = 0;
            $jumlah_lainnya = 0;

            foreach ($cari as $c) {
                $filter = [
                    'id_akun'   => session()->get('id'),
                    'id_akun2'  => $c['id']
                ];
                $cek_kontak = $this->kontakModel->where($filter)->first();

                if ($cek_kontak != null) {
                    $kontak[]   = $c;
                    $jumlah_kontak++;
                } else {
                    $lainnya[]  = $c;
                    $jumlah_lainnya++;
                }
            }
            $response = [
                'status'            => 'ada',
                'kontak'            => $kontak,
                'lainnya'           => $lainnya,
                'jumlah_kontak'     => $jumlah_kontak,
                'jumlah_lainnya'    => $jumlah_lainnya,
                'id_akun'           => session()->get('id'),
            ];
        } else {
            $response = [
                'status'    => null
            ];
        }
        echo json_encode($response);
    }

    public function tambah_kontak()
    {
        $id_akun = $this->request->getVar('id_akun');
        $kondisi = $this->request->getVar('kondisi');

        if ($kondisi == 'tambah') {
            $data = [
                'id_akun'   => session()->get('id'),
                'id_akun2'  => $id_akun,
                'tgl'       => date('Y-m-d H:i:s')
            ];
            $this->kontakModel->save($data);

            $log = 'menambahkan id_akun = ' . $id_akun . ' ke kontak';
        } else {
            $filter = [
                'id_akun'   => session()->get('id'),
                'id_akun2'  => $id_akun,
            ];
            $cari = $this->kontakModel->where($filter)->first();
            $this->kontakModel->delete($cari['id']);

            $log = 'menghapus id_akun = ' . $id_akun . ' dari kontak';
        }

        $data_log = [
            'id_akun'   => session()->get('id'),
            'log'       => $log,
        ];
        $this->logAkunModel->save($data_log);

        echo json_encode('success');
    }
}
