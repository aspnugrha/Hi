<?php

namespace App\Controllers;

use App\Models\Akun_model;
use App\Models\Log_akun_model;
use App\Models\Log_aktif_akun_model;

class Login extends BaseController
{
    public function __construct()
    {
        $this->akunModel            = new Akun_model();
        $this->logAkunModel         = new Log_akun_model();
        $this->logAktifAkunModel    = new Log_aktif_akun_model();

        date_default_timezone_set('Asia/Jakarta');
    }

    public function index()
    {
        $data = [
            'content_foot' => [
                'login/login_foot',
                'universal_foot/toastr_foot'
            ]
        ];
        return view('login/login', $data);
    }

    public function login()
    {
        $email          = $this->request->getVar('email');
        $pass           = $this->request->getVar('pass');

        $cek = $this->akunModel->where('email', $email)->first();

        if ($cek != null) {
            if (password_verify($pass, $cek['pass'])) {
                $data_aktif = [
                    'id_akun'   => $cek['id'],
                    'status'    => 'aktif'
                ];
                $this->logAktifAkunModel->save($data_aktif);

                $user_data = [
                    'id'        => $cek['id'],
                    'user'      => $cek['user'],
                    'email'     => $cek['email'],
                    'aktif'     => $cek['aktif'],
                    'role'      => $cek['role'],
                    'level'     => $cek['level'],
                ];
                session()->set($user_data);

                $response = 'success';
            } else {
                $response = 'salah';
            }
        } else {
            $response = 'null';
        }
        echo json_encode($response);
    }

    public function register()
    {
        $user           = $this->request->getVar('user');
        $email          = $this->request->getVar('email');
        $pass           = $this->request->getVar('pass');
        $confirm_pass   = $this->request->getVar('confirm_pass');

        $cek_email = $this->akunModel->where('email', $email)->first();
        $cek_user  = $this->akunModel->where('user', $user)->first();

        if ($cek_email != null) {
            $response = 'email ada';
            $status = 'gagal';
        } else {
            if ($cek_user != null) {
                $response = 'user ada';
                $status = 'gagal';
            } else {
                $status = 'lolos';
            }
        }

        if ($status != 'gagal') {
            $data = [
                'user'  => $user,
                'email' => $email,
                'pass'  => password_hash($pass, PASSWORD_DEFAULT),
                'aktif' => 'y',
                'role'  => 'user',
                'level' => 3,
            ];

            $this->akunModel->save($data);
            $ambil  = $this->akunModel->where('user', $user)->first();

            $data_log = [
                'id_akun'   => $ambil['id'],
                'log'       => 'baru saja mendaftar'
            ];

            $data_aktif = [
                'id_akun'   => $ambil['id'],
                'status'    => 'aktif'
            ];
            $this->logAkunModel->save($data_log);
            $this->logAktifAkunModel->save($data_aktif);

            $user_data = [
                'id'        => $ambil['id'],
                'user'      => $ambil['user'],
                'email'     => $ambil['email'],
                'aktif'     => $ambil['aktif'],
                'role'      => $ambil['role'],
                'level'     => $ambil['level'],
            ];
            session()->set($user_data);

            $response = 'success';
        }

        echo json_encode($response);
    }

    public function logout()
    {
        $ambil  = $this->akunModel->where('id', session()->get('id'))->first();
        $data_aktif = [
            'id_akun'   => $ambil['id'],
            'status'    => 'nonaktif'
        ];

        $this->logAktifAkunModel->save($data_aktif);
        session()->destroy();

        return redirect()->to('Home');
    }
}
