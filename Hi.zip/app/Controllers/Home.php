<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        if (session()->get('id') == null) {
            return redirect()->to('Login');
        } else {
            if (session()->get('aktif') == 'y') {
                if (session()->get('role') == 'user') {
                    return redirect()->to('all');
                } else {
                    return redirect()->to('A/home');
                }
            } else {
                echo ("Akun tersebut tidak aktif atau dinonaktifkan!");
            }
        }
    }
}
