<div class="container">
    <center><br>
        <img class="profile-lg mt-4 mb-4" src="" alt="" id="foto-profile">
        <h1 id="text-user">User</h1>
        <h5 id="text-kontak">Example@gmail.com <br> 085789101112</h5>

        <p id="text-bio">BIO <br> Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Voluptates, explicabo cumque aliquid excepturi</p>

        <div class="row">
            <div class="col-md-6 col-sm-6">
                <i class="fa fa-users" style="font-size: 50px;font-weight: bold;color: #999;"></i> <b id="text-total-teman">100K</b> <br>
                Friends
            </div>
            <div class="col-md-6 col-sm-6">
                <i class="fa fa-comments" style="font-size: 50px;font-weight: bold;color: #999;"></i> <b id="text-total-pesan">500</b> <br>
                Chats
            </div>
        </div>

        <div class="btn-group">
            <button class="btn btn-primary" aria-labelledby="Edit"><i class="fa fa-pencil"></i></button>
            <button class="btn btn-warning" aria-labelledby="Change Password"><i class="fa fa-lock"></i></button>
            <button class="btn btn-danger" aria-labelledby="Logout"><i class="fa fa-sign-out"></i></button>
        </div>
    </center>
</div><br><br><br>