<?php

namespace App\Models\User;

use CodeIgniter\Model;

class Pesan_model extends Model
{
    protected $table = 'pesan';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_akun1', 'id_akun2', 'tgl', 'created_at', 'updated_at'];
}
