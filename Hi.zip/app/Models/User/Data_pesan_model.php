<?php

namespace App\Models\User;

use CodeIgniter\Model;

class Data_pesan_model extends Model
{
    protected $table = 'data_pesan';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['id_pesan', 'dari', 'pesan', 'file', 'reply', 'status', 'created_at', 'updated_at'];
}
