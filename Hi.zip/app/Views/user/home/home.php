<center>
    <img class="mb-4" width="100%" src="<?php echo base_url() ?>/assets/images/imgs/no-message.jpg" alt="Logo">

    <br><br>
    <h1 class="py-4">Selamat Datang, <?= session()->get('user') ?>!</h1>
    <p class="w-50">Mulailah mengirim pesan ke banyak temanmu. Atau anda dapat mencari teman baru dengan mengklik <i class="text-danger">Pesan Baru</i></p>

    <br><br><br><br>
</center>