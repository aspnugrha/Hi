<?php

namespace App\Models;

use CodeIgniter\Model;

class Akun_model extends Model
{
    protected $table = 'akun';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['user', 'pass', 'email', 'hp', 'aktif', 'role', 'level', 'foto', 'bio', 'created_at', 'updated_at'];
}
