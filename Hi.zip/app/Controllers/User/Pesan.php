<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

use App\Models\Akun_model;
use App\Models\Log_akun_model;
use App\Models\Log_aktif_akun_model;
use App\Models\User\Kontak_model;
use App\Models\User\Pesan_model;
use App\Models\User\Data_pesan_model;
use DateTime;

class Pesan extends BaseController
{
    public function __construct()
    {
        $this->akunModel            = new Akun_model();
        $this->logAkunModel         = new Log_akun_model();
        $this->logAktifAkunModel    = new Log_aktif_akun_model();
        $this->kontakModel          = new Kontak_model();
        $this->pesanModel           = new Pesan_model();
        $this->dataPesanModel       = new Data_pesan_model();

        date_default_timezone_set('Asia/Jakarta');
    }

    public function index()
    {
        $data = [
            'title'         => 'Hi | Pesan',
            'content'       => 'user/pesan/all/all',
            'content_foot'  => [
                'user/pesan/all/all_foot',
                'universal_foot/toastr_foot',
                'universal_foot/pesan_all'
            ]
        ];
        return view('user/layout/wrapper', $data);
    }

    public function pesan_baru()
    {
        $data = [
            'title'        => 'Hi | Buat pesan baru',
            'content'       => 'user/pesan/baru/baru',
            'content_foot'  => [
                'user/pesan/baru/baru_foot',
                'universal_foot/toastr_foot',
                'universal_foot/pesan_all'
            ]
        ];
        return view('user/layout/wrapper', $data);
    }

    // pesan
    public function cek_pesan_masuk()
    {
        $all_pesan = $this->pesanModel->where("id_akun1 LIKE '%" . session()->get('id') . "%' OR id_akun2 LIKE '%" . session()->get('id') . "%'")->findAll();
        $hitung = count($all_pesan);

        $hitung_terkirim = [];
        $all_akun = [];
        $status_selisih = [];

        if ($hitung > 0) {
            foreach ($all_pesan as $ap) {
                $all_pesan_terkirim = $this->dataPesanModel->where(['id_pesan' => $ap['id'], 'status' => 'terkirim'])->findAll();
                $hitung_terkirim[$ap['id']] = count($all_pesan_terkirim);

                if ($hitung_terkirim > 0) {
                    if ($ap['id_akun1'] != session()->get('id')) {
                        $id_akun = $ap['id_akun1'];
                    } else {
                        $id_akun = $ap['id_akun2'];
                    }
                    $all_akun[$ap['id']] = $this->akunModel->where('id', $id_akun)->first();

                    $pesan_terakhir = $this->dataPesanModel->orderBy('id', 'DESC')
                        ->where(['id_pesan' => $ap['id'], 'status' => 'terkirim'])
                        ->limit('1')->first();

                    $awal   = strtotime($pesan_terakhir['created_at']);
                    $akhir  = strtotime(date('Y-m-d H:i:s'));

                    $selisih_detik = $akhir - $awal;

                    if ($selisih_detik <= 10) {
                        $status_selisih[$ap['id']] = 'ya';
                    } else {
                        $status_selisih[$ap['id']] = 'tidak';
                    }
                }
            }
        }

        $status_selisih2 = 'tidak';
        if (count($status_selisih) > 0) {
            if (in_array('ya', $status_selisih)) {
                $status_selisih2 = 'ya';
            }
        }

        $response = [
            'all_pesan'         => $all_pesan,
            'hitung'            => $hitung,
            'hitung_terkirim'   => $hitung_terkirim,
            'all_akun'          => $all_akun,
            'status_selisih'    => $status_selisih2,
        ];
        echo json_encode($response);
    }

    public function cek_all_pesan()
    {
        $pesan = $this->pesanModel->orderBy('created_at', 'DESC')
            ->where("id_akun1 LIKE '%" . session()->get('id') . "%' OR id_akun2 LIKE '%" . session()->get('id') . "%'")
            ->findAll();

        $hitung = count($pesan);

        $akun = [];
        $akun_aktif = [];
        $pesan_terakhir = [];
        $status_aktif = [];
        $jml_pesan_belum_dibaca = [];

        if ($hitung > 0) {
            foreach ($pesan as $p) {
                if ($p['id_akun1'] != session()->get('id')) {
                    $akun[$p['id']] = $this->akunModel->where('id', $p['id_akun1'])->first();
                } else {
                    $akun[$p['id']] = $this->akunModel->where('id', $p['id_akun2'])->first();
                }

                // aktif akun
                $akun_aktif[$p['id']] = $this->logAktifAkunModel->orderBy('id', 'DESC')
                    ->where('id_akun', $akun[$p['id']]['id'])
                    ->limit('1')->first();

                if ($akun_aktif[$p['id']]['status'] != 'aktif') {
                    $awal  = strtotime($akun_aktif[$p['id']]['created_at']);
                    $akhir = strtotime(date('Y-m-d H:i:s'));
                    $diff   = $akhir - $awal;

                    $hari   = floor($diff / (60 * 60 * 24));
                    $jam    = floor($diff / (60 * 60));
                    $menit1 = $diff - $jam * (60 * 60);
                    $menit2 = floor($menit1 / 60);

                    if ($hari != 0) {
                        $status_aktif[$p['id']] = 'aktif ' . $hari . ' hari yang lalu';
                    } else if ($jam != 0) {
                        $status_aktif[$p['id']] = 'aktif ' . $jam . ' jam yang lalu';
                    } else if ($menit2 != 0) {
                        $status_aktif[$p['id']] = 'aktif ' . $menit2 . ' menit yang lalu';
                    } else {
                        $status_aktif[$p['id']] = 'aktif beberapa detik yang lalu';
                    }
                } else {
                    $status_aktif[$p['id']] = 'online';
                }

                // pesan terakhir
                $pesan_terakhir[$p['id']] = $this->dataPesanModel->orderBy('id', 'DESC')
                    ->where('id_pesan', $p['id'])
                    ->limit('1')->first();

                // belum dibaca
                $pesan_belum_dibaca                 = $this->dataPesanModel->where(['id_pesan' => $p['id'], 'status' => 'terkirim', 'dari' => $akun[$p['id']]['id']])->findAll();
                $jml_pesan_belum_dibaca[$p['id']]   = count($pesan_belum_dibaca);
            }
        }

        $data = [
            'hitung'            => $hitung,
            'all_pesan'         => $pesan,
            'akun'              => $akun,
            'akun_aktif'        => $akun_aktif,
            'pesan_terakhir'    => $pesan_terakhir,
            'status_aktif'      => $status_aktif,
            'belum_dibaca'      => $jml_pesan_belum_dibaca,
        ];
        echo json_encode($data);
    }

    public function pesan($slug)
    {
        $akun  = $this->akunModel->where('user', $slug)->first();
        $filter = [
            'id_akun1'  => session()->get('id'),
            'id_akun2'  => $akun['id'],
        ];

        $cek = $this->pesanModel->where($filter)->first();

        if ($cek == null) {
            $filter2 = [
                'id_akun1'  => $akun['id'],
                'id_akun2'  => session()->get('id'),
            ];

            $cek2 = $this->pesanModel->where($filter2)->first();

            if ($cek2 == null) {
                $data_save = [
                    'id_akun1'  => session()->get('id'),
                    'id_akun2'  => $akun['id'],
                    'tgl'       => date('Y-m-d H:i:s')
                ];

                $data_log = [
                    'id_akun'   => session()->get('id'),
                    'log'       => 'mengirim pesan ke akun = ' . $akun['id'],
                ];
                $this->logAkunModel->save($data_log);

                $this->pesanModel->save($data_save);
                $cek2 = $this->pesanModel->where($filter2)->first();
            }

            $cek = $cek2;
        }

        // belum dibaca
        $filter3 = [
            'id_pesan' => $cek['id'],
            'status' => 'terkirim',
            'dari' => $akun['id']
        ];
        $pesan_belum_dibaca = $this->dataPesanModel->where($filter3)->findAll();

        if (count($pesan_belum_dibaca) > 0) {
            foreach ($pesan_belum_dibaca as $br) {
                $data_read = [
                    'id'        => $br['id'],
                    'status'    => 'dibaca',
                ];

                $this->dataPesanModel->save($data_read);
            }
        }

        $data = [
            'title'         => 'Hi | pesan',
            'content'       => 'user/pesan/personal/pesan',
            'content_foot'  => [
                'user/pesan/personal/pesan_foot',
                'universal_foot/toastr_foot'
            ],
            'id_akun'       => $akun['id'],
        ];
        return view('user/layout/wrapper', $data);
    }

    public function load_detail_akun()
    {
        $id_akun    = $this->request->getVar('id_akun');

        $akun       = $this->akunModel->where('id', $id_akun)->first();
        $aktif      = $this->logAktifAkunModel->orderBy('id', 'DESC')
            ->where('id_akun', $akun['id'])
            ->limit('1')->first();

        if ($aktif['status'] != 'aktif') {
            $awal  = strtotime($aktif['created_at']);
            $akhir = strtotime(date('Y-m-d H:i:s'));
            $diff   = $akhir - $awal;

            $hari   = floor($diff / (60 * 60 * 24));
            $jam    = floor($diff / (60 * 60));
            $menit1 = $diff - $jam * (60 * 60);
            $menit2 = floor($menit1 / 60);

            if ($hari != 0) {
                $status_aktif = 'aktif ' . $hari . ' hari yang lalu';
            } else if ($jam != 0) {
                $status_aktif = 'aktif ' . $jam . ' jam yang lalu';
            } else if ($menit2 != 0) {
                $status_aktif = 'aktif ' . $menit2 . ' menit yang lalu';
            } else {
                $status_aktif = 'aktif beberapa detik yang lalu';
            }
            $aktif2 = 'tidak';
        } else {
            $aktif2 = 'aktif';
            $status_aktif = 'online';
        }

        $data = [
            'akun'          => $akun,
            'aktif'         => $aktif2,
            'status_aktif'  => $status_aktif,
        ];

        echo json_encode($data);
    }

    public function load_data_pesan()
    {
        $id_akun    = $this->request->getVar('id_akun');
        $akun       = $this->akunModel->where('id', $id_akun)->first();

        $filter = [
            'id_akun1'  => session()->get('id'),
            'id_akun2'  => $akun['id'],
        ];
        $filter2 = [
            'id_akun1'  => $akun['id'],
            'id_akun2'  => session()->get('id'),
        ];

        $cek = $this->pesanModel->where($filter)->first();
        if ($cek == null) {
            $cek = $this->pesanModel->where($filter2)->first();
        }

        $data_pesan = $this->dataPesanModel->orderBy('created_at', 'ASC')
            ->where('id_pesan', $cek['id'])
            ->findAll();

        // belum dibaca
        $filter3 = [
            'id_pesan' => $cek['id'],
            'status' => 'terkirim',
            'dari' => $akun['id']
        ];
        $pesan_belum_dibaca = $this->dataPesanModel->where($filter3)->findAll();

        if (count($pesan_belum_dibaca) > 0) {
            // foreach ($pesan_belum_dibaca as $br) {
            //     $data_read = [
            //         'id'        => $br['id'],
            //         'status'    => 'dibaca',
            //     ];

            //     $this->dataPesanModel->save($data_read);
            // }

            $pesan_belum_dibaca2 = 'ada';
        } else {
            $pesan_belum_dibaca2 = null;
        }

        $hitung = count($data_pesan);

        if ($hitung > 0) {
            $data_pesan2 = [];
            foreach ($data_pesan as $dp) {
                $data_pesan2[] = [
                    'id'            => $dp['id'],
                    'dari'          => $dp['dari'],
                    'pesan'         => $dp['pesan'],
                    'file'          => $dp['file'],
                    'reply'         => $dp['reply'],
                    'status'        => $dp['status'],
                    'created_at'    => $dp['created_at'],
                    'updated_at'    => $dp['updated_at'],
                    'tgl'           => date('H:i | M d', strtotime($dp['created_at'])),
                ];
            }
        } else {
            $data_pesan2 = $data_pesan;
        }

        $data = [
            'hitung'                    => $hitung,
            'data_pesan'                => $data_pesan2,
            'pesan_belum_dibaca'        => $pesan_belum_dibaca2,
            'jml_pesan_belum_dibaca'    => count($pesan_belum_dibaca),
        ];

        echo json_encode($data);
    }

    public function pesan_dibaca_act()
    {
        $id_akun    = $this->request->getVar('id_akun');
        $akun       = $this->akunModel->where('id', $id_akun)->first();

        $filter = [
            'id_akun1'  => session()->get('id'),
            'id_akun2'  => $akun['id'],
        ];
        $filter2 = [
            'id_akun1'  => $akun['id'],
            'id_akun2'  => session()->get('id'),
        ];

        $cek = $this->pesanModel->where($filter)->first();
        if ($cek == null) {
            $cek = $this->pesanModel->where($filter2)->first();
        }

        // belum dibaca
        $filter3 = [
            'id_pesan' => $cek['id'],
            'status' => 'terkirim',
            'dari' => $akun['id']
        ];
        $pesan_belum_dibaca = $this->dataPesanModel->where($filter3)->findAll();

        if (count($pesan_belum_dibaca) > 0) {
            foreach ($pesan_belum_dibaca as $br) {
                $data_read = [
                    'id'        => $br['id'],
                    'status'    => 'dibaca',
                ];

                $this->dataPesanModel->save($data_read);
            }
        }
        echo json_encode('success');
    }

    public function kirim_pesan()
    {
        $id_akun = $this->request->getVar('id_akun');
        $pesan   = $this->request->getVar('pesan');

        $cek_pesan1 = $this->pesanModel->where(['id_akun1' => $id_akun, 'id_akun2' => session()->get('id')])->first();
        $cek_pesan2 = $this->pesanModel->where(['id_akun1' => session()->get('id'), 'id_akun2' => $id_akun])->first();

        if ($cek_pesan1 != null) {
            $pesan2 = $cek_pesan1;
        } else {
            $pesan2 = $cek_pesan2;
        }

        $data = [
            'id_pesan'  => $pesan2['id'],
            'dari'      => session()->get('id'),
            'pesan'     => $pesan,
            'status'    => 'terkirim',
        ];

        $data_log = [
            'id_akun'   => session()->get('id'),
            'log'       => 'mengirim pesan ke akun = ' . $id_akun,
        ];
        $this->logAkunModel->save($data_log);
        $this->dataPesanModel->save($data);

        echo json_encode('success');
    }

    public function coba()
    {
        $awal   = strtotime('2022-08-14 18:51:28');
        $akhir  = strtotime(date('Y-m-d H:i:s'));
        $diff   = $akhir - $awal;

        $hari   = floor($diff / (60 * 60 * 24));
        $jam    = floor($diff / (60 * 60));
        $menit1 = $diff - $jam * (60 * 60);
        $menit2 = floor($menit1 / 60);

        dd($hari, $jam, $menit2);
    }

    public function coba2()
    {
        $awal   = strtotime('2022-08-19 10:33:28');
        $akhir  = strtotime(date('Y-m-d H:i:s'));

        dd($akhir - $awal);
    }
}
