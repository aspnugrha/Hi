<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>/assets/images/logo/logo.png">
    <title><?= $title ?></title>

    <link href="<?= base_url(); ?>/assets/plugins/bootstrap52/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>/assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/assets/plugins/toastr/css/toastr.min.css" rel="stylesheet">

    <style>
        /* stylelint-disable selector-list-comma-newline-after */

        .blog-header {
            border-bottom: 1px solid #e5e5e5;
        }

        .blog-header-logo {
            font-family: "Playfair Display", Georgia, "Times New Roman", serif
                /*rtl:Amiri, Georgia, "Times New Roman", serif*/
            ;
            font-size: 2.25rem;
        }

        .blog-header-logo:hover {
            text-decoration: none;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: "Playfair Display", Georgia, "Times New Roman", serif rtl, Amiri, Georgia, "Times New Roman", serif;
        }

        .display-4 {
            font-size: 2.5rem;
        }

        @media (min-width: 768px) {
            .display-4 {
                font-size: 3rem;
            }
        }

        .flex-auto {
            flex: 0 0 auto;
        }

        .h-250 {
            height: 250px;
        }

        @media (min-width: 768px) {
            .h-md-250 {
                height: 250px;
            }
        }

        /* Pagination */
        .blog-pagination {
            margin-bottom: 4rem;
        }

        /*
 * Blog posts
 */
        .blog-post {
            margin-bottom: 4rem;
        }

        .blog-post-title {
            font-size: 2.5rem;
        }

        .blog-post-meta {
            margin-bottom: 1.25rem;
            color: #727272;
        }

        /*
 * Footer
 */
        .blog-footer {
            padding: 2.5rem 0;
            color: #727272;
            text-align: center;
            background-color: #f9f9f9;
            border-top: .05rem solid #e5e5e5;
        }

        .blog-footer p:last-child {
            margin-bottom: 0;
        }

        #chat3 .form-control {
            border-color: transparent;
        }

        #chat3 .form-control:focus {
            border-color: transparent;
            box-shadow: inset 0px 0px 0px 1px transparent;
        }

        .badge-dot {
            border-radius: 50%;
            height: 10px;
            width: 10px;
            margin-left: 2.9rem;
            margin-top: -.75rem;
        }

        .img-logo {
            width: 40px;
            height: 40px;
        }

        .profile-sm {
            width: 60px;
            height: 60px;
            border-radius: 100%;
            border: 2px solid #eee;
            padding: 1px;
        }

        .profile-lg {
            width: 250px;
            height: 250px;
            border-radius: 100%;
            border: 8px solid #eee;
            padding: 10px;
        }

        .icon-md {
            font-size: 20px;
        }

        .div-new-chat {
            position: fixed;
            z-index: 3;
            bottom: 2%;
            right: 5%;
        }

        .div-scroll-down {
            position: absolute;
            z-index: 3;
            bottom: 10%;
        }

        .a-link-pointer {
            text-decoration: none;
        }

        .a-link-pointer:hover {
            cursor: pointer;
        }

        .custome-scroll {
            scrollbar-color: #d4aa70 #e4e4e4;
            scrollbar-width: thin;
        }

        .custome-scroll::-webkit-scrollbar {
            width: 10px;
        }

        .custome-scroll::-webkit-scrollbar-track {
            background-color: #e4e4e4;
        }

        .custome-scroll::-webkit-scrollbar-thumb {
            border-radius: 50px;
            background-image: linear-gradient(180deg, #3867df 0%, #2dce55 99%);
            -webkit-box-shaddow: inset 2px 2px 5px 0px rgba(#fff, 0.5);
        }

        @font-face {
            font-family: nunito-extra-bold;
            src: url('../../assets/font/nunito/Nunito-ExtraBold.ttf');
        }

        @font-face {
            font-family: nunito-regular;
            src: url('../../assets/font/nunito/Nunito-Regular.ttf');
        }

        .nama-web {
            font-family: nunito-extra-bold;
            font-size: 35px;
        }

        * {
            font-family: nunito-regular;
        }
    </style>
</head>

<body style="background-color: #eee;">

    <div>
        <div class="container">
            <header class="blog-header lh-1 py-3">
                <div class="row flex-nowrap justify-content-between align-items-center">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <a href="<?= base_url() ?>" class="a-link-pointer">
                            <img class="" width="40px" src="<?php echo base_url() ?>/assets/images/logo/logo.png" alt="Logo">
                        </a>
                        <ul class="navbar-nav mb-2">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle nama-web" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                                    &nbsp; Hi
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="dropdown-item" href="<?= base_url(); ?>/profile">
                                            <div class="d-flex justify-content-between">
                                                <div class="d-flex flex-row">
                                                    <div class="position-relative">
                                                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava6-bg.webp" alt="avatar 3" style="width: 50px; height: 50px;">
                                                    </div>
                                                    <div class="pt-1 ms-2 text-start" style="padding-right: 10px;">
                                                        <h4 class="fw-bold mb-0"><?= session()->get('user') ?></h4>
                                                        <p class="small text-muted"><?= session()->get('email') ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <!-- <hr> -->
                                    <!-- <li><a class="dropdown-item" href="#"><i class="fa fa-user"></i> Profile</a></li> -->
                                    <li><a class="dropdown-item" href="#"><i class="fa fa-cog"></i> Setting</a></li>
                                    <!-- <hr> -->
                                    <li><a class="dropdown-item" href="<?= base_url(); ?>/logout"><i class="fa fa-sign-out icon-md"></i> Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </header>
        </div>
    </div>

    <a class="div-new-chat btn btn-lg btn-primary" href="<?= base_url(); ?>/pesan/baru"><i class="fa fa-comment"></i></a>