<script>
    var base_url = '<?php echo base_url() ?>';
    var id_akun = $('#id_akun').val();

    $(document).ready(function() {
        load_pesan();
        setTimeout(function() {
            scroll_down();
        }, 1000);

        $('#btn-kirim-pesan').attr('disabled', true);

        $('#input-pesan').each(function() {
            this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;');
        }).on('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });

        window.setInterval(function() {
            load_pesan();
        }, 5000);

        // $(window).scroll(function() {
        //     if (document.body.scrollTop > 1) {
        //         alert('Hello Guys');
        //     }
        // });

        // window.onscroll = function() {
        //     alert('hallo guys');
        // }

        $('#data-pesan').on('scroll', function(e) {
            var t = $(this);
            if (t[0].scrollHeight - t.scrollTop() - t.outerHeight() < 1) {
                pesan_dibaca_act();
            }
        });

    });


    function clear_input_pesan() {
        $('#input-pesan').val('');
    }

    function load_pesan() {
        load_detail_akun();
        load_data_pesan();
    }

    function load_detail_akun() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/load_detail_akun",
            data: {
                id_akun: id_akun,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                $('#nama-akun').text(response.akun['user']);
                $('#aktif-akun').text(response.status_aktif);

                if (response.aktif == 'aktif') {
                    $('#div-badge-aktif').html('<span class="position-absolute translate-middle p-2 bg-success border border-light rounded-circle"></span>');
                } else {
                    $('#div-badge-aktif').html('');
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    function load_data_pesan() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/load_data_pesan",
            data: {
                id_akun: id_akun,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                if (response.hitung > 0) {
                    var html = '';
                    response.data_pesan.forEach(dp => {
                        if (dp['dari'] != id_akun) {
                            var start_end = 'end';
                            var bg = 'text-white bg-primary';
                            var style = '';
                            var warna_pesan = 'text-white';

                            if (dp['status'] == 'dibaca') {
                                var status_pesan = '<i class="w-100 text-end fa fa-check px-2" style="font-size: 18px;"></i>';
                            } else {
                                var status_pesan = '';
                            }
                        } else {
                            var start_end = 'start';
                            var bg = '';
                            var style = 'style="background-color: #f5f6f7;"';
                            var warna_pesan = '';
                            var status_pesan = '';
                        }

                        html += '<div class="d-flex flex-row justify-content-' + start_end + '">' +
                            '<div class="text-start" style="width: auto;max-width: 80%;">' +
                            '<div class="small p-2 me-3 mb-1 ' + warna_pesan + ' rounded-3 ' + bg + '" ' + style + '>' +
                            '<p class="pesan m-0 p-0" style="font-size: 16px;">' + dp['pesan'] + '</p>' +
                            status_pesan +
                            '</div>' +
                            '<p class="small me-4 mb-3 rounded-3 text-muted text-' + start_end + '">' + dp['tgl'] + '</p>' +
                            '</div>' +
                            '</div>';
                    });
                    $('#data-pesan').html(html);
                } else {
                    var html = '<center><h5 style="margin-top: 130px;">Mulailah mengirim pesan!</h5><p>Sapa teman anda dan jalin persahabatan.</p></center>';
                    $('#data-pesan').html(html);
                }

                if (response.pesan_belum_dibaca == 'ada') {
                    var html_btn_scroll = '<button type="button" class="btn btn-primary div-scroll-down" style="border-radius: 100%;" onclick="pesan_dibaca_act()">' +
                        '<i class="fa fa-angle-double-down"></i>' +
                        '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">' +
                        response.jml_pesan_belum_dibaca +
                        '<span class="visually-hidden">unread messages</span>' +
                        '</span>' +
                        '</button>';

                    $('#div-btn-scroll').html(html_btn_scroll);
                } else {
                    $('#div-btn-scroll').html('');
                }
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    function scroll_down() {
        var objDiv = document.getElementById("data-pesan");
        objDiv.scrollTop = objDiv.scrollHeight;
    }

    function pesan_dibaca_act() {
        var objDiv = document.getElementById("data-pesan");
        objDiv.scrollTop = objDiv.scrollHeight;

        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/pesan_dibaca_act",
            data: {
                id_akun: id_akun,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                $('#div-btn-scroll').html('');
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    function cek_pesan() {
        var pesan = $('#input-pesan').val();

        if (pesan != '') {
            kirim_pesan();
        } else {
            show_toastr("error", "Error", "Isi pesan sebelum mengirim!", "center");
        }
    }

    function kirim_pesan() {
        var pesan = $('#input-pesan').val();

        $.ajax({
            type: "POST",
            url: base_url + "/User/Pesan/kirim_pesan",
            data: {
                id_akun: id_akun,
                pesan: pesan,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                load_pesan();
                clear_input_pesan();
                setTimeout(function() {
                    scroll_down();
                }, 500);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>