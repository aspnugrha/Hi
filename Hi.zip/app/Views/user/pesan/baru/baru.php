<h4 class="text-start mt-3 mb-3">New Chat</h4>
<div class="d-flex mb-3" role="search">
    <?= csrf_field() ?>
    <input class="form-control me-2" type="search" placeholder="Search username, email, atau nomor handphone" aria-label="Search" id="search" name="search" onkeydown="cari_akun(event)">
</div>

<div id="loading">
    <center><i class="fa fa-spin fa-spinner" style="font-size: 20px;"></i> Loading...</center>
</div>

<ul class="nav nav-tabs" data-bs-tabs="tabs">
    <li class="nav-item">
        <a class="nav-link active" aria-current="true" data-bs-toggle="tab" href="#kontak">Kontak</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#lainnya">Lainnya</a>
    </li>
</ul>
<div class="tab-content">
    <div class="tab-pane active" id="kontak">
        <div class="text-start mb-2">
            <p class="text-muted my-2" id="total-cari-kontak"></p>
        </div>

        <div data-mdb-perfect-scrollbar="true" style="position: relative; height: auto">
            <ul class="list-unstyled mb-0" id="div-cari-kontak">

            </ul>
        </div>

    </div>
    <div class="tab-pane" id="lainnya">
        <div class="text-start mb-2">
            <p class="text-muted my-2" id="total-cari-lainnya"></p>
        </div>

        <div data-mdb-perfect-scrollbar="true" style="position: relative; height: auto">
            <ul class="list-unstyled mb-0" id="div-cari-lainnya">

            </ul>
        </div>
    </div>
    <br><br><br>
</div>