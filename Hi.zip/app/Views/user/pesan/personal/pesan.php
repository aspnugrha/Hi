<form>
    <?= csrf_field() ?>
    <input type="hidden" id="id_akun" value="<?= $id_akun ?>">
</form>

<ul class="list-unstyled mb-0">
    <li class="p-2 border-bottom">
        <div class="d-flex justify-content-between">
            <div class="d-flex flex-row">
                <div class="position-relative">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp" alt="avatar" class="d-flex align-self-center me-3" width="60">
                    <div id="div-badge-aktif"></div>
                </div>
                <div class="pt-1 text-start">
                    <h4 class="fw-bold mb-0" id="nama-akun"></h4>
                    <p class="small text-muted" id="aktif-akun"></p>
                </div>
            </div>
            <div class="pt-1">
                <!-- <p class="small text-muted mb-1"></p> -->
                <span class="badge bg-danger rounded-pill"></span>
            </div>
        </div>
    </li>
</ul>

<div class="pt-3 pe-3 custome-scroll" data-mdb-perfect-scrollbar="true" style="position: relative; height: 400px;overflow: auto;padding: 10px;border: 1.5px solid #ddd;border-radius: 5px;background-image: linear-gradient(180deg, #9097c4 0%, #ffd4b1 99%);" id="data-pesan">

    <!-- <div class="d-flex flex-row justify-content-start">
        <div class="text-start" style="width: auto;max-width: 80%;">
            <div class="small p-2 ms-3 mb-1 rounded-3" style="background-color: #f5f6f7;">
                <p class="pesan m-0 p-0">
                    Lorem ipsum
                    dolor
                    sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore
                    magna aliqua.
                </p>
            </div>
            <p class="small ms-4 mb-3 rounded-3 text-muted text-start">12:00 PM | Aug 13</p>
        </div>
    </div>

    <div class="d-flex flex-row justify-content-end">
        <div class="text-start" style="width: auto;max-width: 80%;">
            <div class="small p-2 me-3 mb-1 text-white rounded-3 bg-primary">
                <p class="pesan m-0 p-0">
                    Ut enim ad minim veniam,
                    quis
                    nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
                <i class="w-100 text-end fa fa-check px-2" style="font-size: 18px;"></i>
            </div>
            <p class="small me-4 mb-3 rounded-3 text-muted text-end">12:00 PM | Aug 13</p>
        </div>
    </div> -->

</div>
<div class="d-flex justify-content-end" style="padding-right: 30px;" id="div-btn-scroll">

</div>

<div class="text-muted d-flex justify-content-start align-items-center pe-3 pt-3 mt-2 mb-4">
    <!-- <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava6-bg.webp" alt="avatar 3" style="width: 40px; height: 100%;"> -->
    <textarea class="form-control" placeholder="Tulis pesan" rows="1" id="input-pesan"></textarea>
    <a class="ms-2 a-link-pointer text-muted"><i class=" fa fa-paperclip" style="font-size: 25px;"></i></a>
    <a class="ms-3 a-link-pointer text-muted"><i class=" fa fa-smile-o" style="font-size: 25px;"></i></a>
    <a class="ms-3 a-link-pointer" onclick="cek_pesan()" id="btn-kirim-pesan"><i class="fa fa-paper-plane" style="font-size: 25px;"></i></a>
</div>