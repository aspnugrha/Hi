<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

use App\Models\Akun_model;
use App\Models\Log_akun_model;
use App\Models\Log_aktif_akun_model;

class Home extends BaseController
{
    public function __construct()
    {
        $this->akunModel            = new Akun_model();
        $this->logAkunModel         = new Log_akun_model();
        $this->logAktifAkunModel    = new Log_aktif_akun_model();
    }

    public function index()
    {
        $data = [
            'title'         => 'Hi | Welcome ' . session()->get('user'),
            'content'       => 'user/pesan/all/all',
            'content_foot'  => [
                'user/pesan/all/all_foot',
                'universal_foot/toastr_foot'
            ]
        ];
        return view('user/layout/wrapper', $data);
    }
}
