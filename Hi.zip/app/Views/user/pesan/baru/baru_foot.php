<script>
    var base_url = '<?php echo base_url() ?>';

    $(document).ready(function() {
        clear_search();
        load_kontak();
        $('#loading').hide();
        $('#total-cari').text('');
    });

    function load_kontak() {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Kontak/load_kontak",
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
            },
            success: function(response) {
                if (response.status == 'ada') {
                    var html_kontak = '';

                    response.kontak.forEach(c => {
                        html_kontak += '<li class="p-2 border-bottom">' +
                            '<div class="d-flex justify-content-between">' +
                            '<div class="d-flex flex-row">' +
                            '<div>' +
                            '<img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp" alt="avatar" class="d-flex align-self-center me-3" width="60">' +
                            '<span class="badge bg-success badge-dot"></span>' +
                            '</div>' +
                            '<div class="pt-1 text-start">' +
                            '<h4 class="fw-bold mb-0">' + c['user'] + '</h4>' +
                            '<p class="small text-muted">' + c['email'] + '</p>' +
                            '</div>' +
                            '</div>' +
                            '<div class="pt-1">' +
                            '<a class="btn btn-primary" href="' + base_url + '/pesan/' + c['user'] + '" alt="pesan"><i class="fa fa-comment"></i></a>&nbsp;' +
                            '<button class="btn btn-danger" onclick="kontak_act(' + c['id'] + '), `hapus`" alt="hapus kontak"><i class="fa fa-close"></i></button>' +
                            '</div>' +
                            '</div>' +
                            '</li>';
                    });

                    $('#div-cari-kontak').html(html_kontak);
                    $('#total-cari-kontak').text('Result: ' + response.hitung + ' akun');

                } else {
                    $('#div-cari-kontak').html('');
                    $('#total-cari-kontak').text('Result: 0');
                }
                $('#div-cari-lainnya').html('');
                $('#total-cari-lainnya').text('Result: 0');
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    function clear_search() {
        $('#search').val('');
    }

    function cari_akun(event) {
        if (event.keyCode == 13) {
            cari_akun2();
        }
    }

    function cari_akun2() {
        var search = $('#search').val();

        $.ajax({
            type: "POST",
            url: base_url + "/User/Kontak/cari_akun",
            data: {
                search: search,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
                $('#loading').show();
            },
            success: function(response) {
                if (response.status == 'ada') {
                    var html_kontak = '';
                    var html_lainnya = '';

                    if (response.jumlah_kontak > 0) {
                        response.kontak.forEach(c => {
                            html_kontak += '<li class="p-2 border-bottom">' +
                                '<div class="d-flex justify-content-between">' +
                                '<div class="d-flex flex-row">' +
                                '<div>' +
                                '<img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp" alt="avatar" class="d-flex align-self-center me-3" width="60">' +
                                '<span class="badge bg-success badge-dot"></span>' +
                                '</div>' +
                                '<div class="pt-1 text-start">' +
                                '<h4 class="fw-bold mb-0">' + c['user'] + '</h4>' +
                                '<p class="small text-muted">' + c['email'] + '</p>' +
                                '</div>' +
                                '</div>' +
                                '<div class="pt-1">' +
                                '<a class="btn btn-primary" href="' + base_url + '/pesan/' + c['user'] + '" alt="pesan"><i class="fa fa-comment"></i></a>&nbsp;' +
                                '<button class="btn btn-danger" onclick="kontak_act(' + c['id'] + '), `hapus`"><i class="fa fa-close"></i></button>' +
                                '</div>' +
                                '</div>' +
                                '</li>';
                        });

                        $('#div-cari-kontak').html(html_kontak);
                        $('#total-cari-kontak').text('Result: ' + response.jumlah_kontak + ' akun');
                    } else {
                        $('#div-cari-kontak').html('');
                        $('#total-cari-kontak').text('Result: 0');
                    }

                    if (response.jumlah_lainnya > 0) {
                        response.lainnya.forEach(c => {
                            if (response.id_akun != c['id']) {
                                html_lainnya += '<li class="p-2 border-bottom">' +
                                    '<div class="d-flex justify-content-between">' +
                                    '<div class="d-flex flex-row">' +
                                    '<div>' +
                                    '<img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava1-bg.webp" alt="avatar" class="d-flex align-self-center me-3" width="60">' +
                                    '<span class="badge bg-success badge-dot"></span>' +
                                    '</div>' +
                                    '<div class="pt-1 text-start">' +
                                    '<h4 class="fw-bold mb-0">' + c['user'] + '</h4>' +
                                    '<p class="small text-muted">' + c['email'] + '</p>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="pt-1">' +
                                    '<button class="btn btn-success" onclick="kontak_act(' + c['id'] + ', `tambah`)"><i class="fa fa-plus-square"></i> Tambah Kontak</button>' +
                                    '</div>' +
                                    '</div>' +
                                    '</li>';
                            }
                        });

                        $('#div-cari-lainnya').html(html_lainnya);
                        $('#total-cari-lainnya').text('Result: ' + response.jumlah_lainnya + ' akun');
                    } else {
                        $('#div-cari-lainnya').html('');
                        $('#total-cari-lainnya').text('Result: 0');
                    }

                } else {
                    $('#div-cari-kontak').html('');
                    $('#div-cari-lainnya').html('');
                    $('#total-cari-kontak').text('Result: 0');
                    $('#total-cari-lainnya').text('Result: 0');
                }
            },
            complete: function() {
                $('#loading').hide();
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    function kontak_act(id_akun, kondisi) {
        $.ajax({
            type: "POST",
            url: base_url + "/User/Kontak/tambah_kontak",
            data: {
                id_akun: id_akun,
                kondisi: kondisi,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
                $('#loading').show();
            },
            success: function(response) {
                if (kondisi == 'tambah') {
                    show_toastr("success", "Success", "Berhasil disimpan ke kontak!", "center");
                } else {
                    show_toastr("success", "Success", "kontak berhasil dihapus!", "center");
                }
                cari_akun2();
            },
            complete: function() {
                $('#loading').hide();
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>