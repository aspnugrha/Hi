<script>
    var base_url = '<?php echo base_url() ?>';

    $(document).ready(function() {
        clear_register();
        clear_login();
        div_view('login');

        document.getElementById('pass').addEventListener("keydown", function(e) {
            if (e.code === "Enter") {
                cek_login();
            }
        });
    });

    function div_view(kondisi) {
        if (kondisi == 'login') {
            $('.div-login').show();
            $('.div-register').hide();
        } else {
            $('.div-login').hide();
            $('.div-register').show();
        }
    }

    function clear_login() {
        $('#email').val('');
        $('#pass').val('');
    }

    function clear_register() {
        $('#user-register').val('');
        $('#email-register').val('');
        $('#pass-register').val('');
        $('#confirm_pass').val('');
    }

    // login
    function cek_login() {
        var email = $('#email').val();
        var pass = $('#pass').val();

        if (email != '' && pass != '') {
            login();
        } else {
            show_toastr("error", "Error", "Email dan Password tidak boleh kosong", "center");
        }
    }

    function login() {
        var email = $('#email').val();
        var pass = $('#pass').val();

        $.ajax({
            type: "POST",
            url: base_url + "/Login/login",
            data: {
                email: email,
                pass: pass,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
                $('#btn-login').attr('disabled', true);
                $('#btn-login').text('loading...');
            },
            success: function(response) {
                if (response == 'salah') {
                    show_toastr("error", "Error", "Email dan Password salah!", "center");
                } else if (response == 'null') {
                    show_toastr("error", "Error", "Email tidak terdaftar! Silahkan Register untuk membuat akun.", "center");
                } else {
                    show_toastr("success", "Success", "Login berhasil!", "center");
                    setTimeout(function() {
                        window.location = base_url;
                    }, 1000);
                }
            },
            complete: function() {
                $('#btn-login').attr('disabled', false);
                $('#btn-login').text('Login');
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }

    //register
    function cek_register() {
        var user = $('#user-register').val();
        var email = $('#email-register').val();
        var pass = $('#pass-register').val();
        var confirm_pass = $('#confirm_pass').val();

        if (user != '' && email != '' && pass != '' && confirm_pass != '') {
            if (pass != confirm_pass) {
                show_toastr("error", "Error", "Password & Confirm Password tidak cocok!", "center");
            } else {
                if (pass.length < 4) {
                    show_toastr("error", "Error", "Password minimal 4 karakter!", "center");
                } else {
                    register();
                }
            }
        } else {
            show_toastr("error", "Error", "Seluruh data harus diisi", "center");
        }
    }

    function register() {
        var user = $('#user-register').val();
        var email = $('#email-register').val();
        var pass = $('#pass-register').val();
        var confirm_pass = $('#confirm_pass').val();

        $.ajax({
            type: "POST",
            url: base_url + "/Login/register",
            data: {
                user: user,
                email: email,
                pass: pass,
                confirm_pass: confirm_pass,
            },
            dataType: "json",
            beforeSend: function(e) {
                if (e && e.overrideMimeType) {
                    e.overrideMimeType("application/json;charset=UTF-8");
                }
                $('#btn-register').attr('disabled', true);
                $('#btn-register').text('loading...');
            },
            success: function(response) {
                if (response == 'email ada') {
                    show_toastr("error", "Error", "Email tersebut sudah terdaftar!", "center");
                } else if (response == 'user ada') {
                    show_toastr("error", "Error", "Username tersebut sudah terdaftar!", "center");
                } else {
                    show_toastr("success", "Success", "Register akun berhasil!", "center");
                    setTimeout(function() {
                        window.location = base_url;
                    }, 1000);
                }
            },
            complete: function() {
                $('#btn-register').attr('disabled', false);
                $('#btn-register').text('Register');
            },
            error: function(xhr, ajaxOptions, thrownError) {
                alert(xhr.responseText);
            }
        });
    }
</script>