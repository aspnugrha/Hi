<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;

use App\Models\Akun_model;
use App\Models\Log_akun_model;
use App\Models\Log_aktif_akun_model;
use App\Models\User\Kontak_model;
use App\Models\User\Pesan_model;
use App\Models\User\Data_pesan_model;
use DateTime;

class Profile extends BaseController
{
    public function __construct()
    {
        $this->akunModel            = new Akun_model();
        $this->logAkunModel         = new Log_akun_model();
        $this->logAktifAkunModel    = new Log_aktif_akun_model();
        $this->kontakModel          = new Kontak_model();
        $this->pesanModel           = new Pesan_model();
        $this->dataPesanModel       = new Data_pesan_model();

        date_default_timezone_set('Asia/Jakarta');
    }

    public function index()
    {
        $data = [
            'title'         => 'Hi | Profile',
            'content'       => 'user/profile/profile',
            'content_foot'  => [
                'user/profile/profile_foot',
                'universal_foot/toastr_foot',
                'universal_foot/pesan_all'
            ]
        ];
        return view('user/layout/wrapper', $data);
    }

    public function load_profile()
    {
        $akun       = $this->akunModel->where('id', session()->get('id'))->first();
        $teman      = $this->kontakModel->where("id_akun LIKE '%" . session()->get('id') . "%' OR id_akun2 LIKE '%" . session()->get('id') . "%'")->findAll();
        $all_pesan  = $this->pesanModel->where("id_akun1 LIKE '%" . session()->get('id') . "%' OR id_akun2 LIKE '%" . session()->get('id') . "%'")->findAll();

        $jumlah_pesan = 0;

        if (count($all_pesan) > 0) {
            foreach ($all_pesan as $ap) {
                $data_pesan     = $this->dataPesanModel->where('id_pesan', $ap['id'])->findAll();
                $hitung         = count($data_pesan);
                $jumlah_pesan   = $jumlah_pesan + $hitung;
            }
        }

        $data = [
            'akun'          => $akun,
            'jumlah_teman'  => count($teman),
            'jumlah_pesan'  => $jumlah_pesan,
        ];
        echo json_encode($data);
    }
}
